# PhyG-MARL Lite - 项目规格（V1.0）

## 项目目标
实现轻量化动态电网攻防强化学习框架，3000~5000行Python代码。
核心创新：动态网络-物理环境 + Physics-aware Graph Encoder (KCL归纳偏置) + Transformer Temporal Memory。

## 技术栈约束
- Python 3.10+
- PyTorch 2.0+ (CPU/GPU)
- PyTorch Geometric (PyG) 用于GNN
- pandapower 用于潮流计算
- Gymnasium 环境接口

## 模块职责划分（严格隔离）

### 1. 环境模块 (env/)
- **cpgrid_env.py**: Gymnasium.Env主类，step()严格遵循：Action -> Attack -> Topology -> PowerFlow -> Observation -> Reward -> Done。
- **topology_manager.py**: 管理节点/边，删边/恢复边，返回PyG格式Data对象。
- **powerflow_solver.py**: 封装pandapower，输入拓扑返回电压/角度/潮流。
- **attack_simulator.py**: 实现FDI(改观测)、Breaker(断线)、DoS(遮蔽观测)。
- **observation_builder.py**: 将Graph + PowerFlow结果组装为节点/边特征张量。
- **reward_calculator.py**: 实现简化奖励 = 电压稳定奖励 + 负荷保持奖励 - 攻击惩罚。
- **termination.py**: 判定系统崩溃(大范围失压/解列)或超时。

### 2. 图神经网络模块 (graph/)
- **physics_gnn.py**: 实现带KCL残差的GAT层，严格遵循公式 h = σ(Ws*h + Σα*Wn*h_j - λ*Wkcl*r_KCL)。
- **graph_encoder.py**: 堆叠2层Physics GNN + 注意力池化，输出图嵌入。

### 3. 记忆模块 (memory/)
- **transformer_memory.py**: 接收历史K帧图嵌入序列，通过Transformer Encoder输出记忆向量(无交叉注意力)。

### 4. 策略模块 (policy/)
- **actor.py**: 输入(局部观测 + 全局记忆向量)，输出动作分布。

### 5. 训练适配器 (adapter/)
- **light_mappo_adapter.py**: 实现最简MAPPO训练循环(参数共享、GAE、PPO Clip)，Critic使用全局状态(不加轻量化，保持原版)。

## 代码规模约束
- 核心模块总行数 ≤ 5000行（不含注释）。
- 每个模块需包含基础单元测试（用assert验证张量形状和物理残差计算）。

## 删除清单（Lite不实现）
- ❌ Topology Predictor
- ❌ Topology-aware GAE
- ❌ Physics Regularization loss
- ❌ Lightweight Critic（使用MAPPO默认）
- ❌ Cross Attention（仅Transformer Encoder）