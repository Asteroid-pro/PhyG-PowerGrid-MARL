# PhyG 项目设计与实验完整说明

> 本文档不是论文成稿，也不采用论文排版格式。它用于准确记录项目的真实实现、实验协议、结果、可支持的结论和写作边界，帮助后续完成论文。引用数值前应优先核对对应 CSV；文献综述、引文编号和外部方法的原始出处需在正式论文中另行补充。

## 1. 项目要解决的问题

本项目研究 IEEE 14-bus 电力信息物理系统在 FDI、DoS 和 Breaker 混合攻击下的多智能体主动防御。核心矛盾不是单纯追求最高生存率，而是在以下目标之间取得平衡：

- 尽可能让潮流持续收敛并运行至 200 步上限；
- 尽量保留负荷，避免为了安全而过度减载；
- 减少高、低电压越限和线路过载；
- 限制发电机电压支撑与负荷控制成本；
- 在不同攻击轨迹和训练随机种子下保持稳定。

项目将 14 个母线视为 14 个协同智能体，采用集中式训练、分布式执行（CTDE）。主模型 PhyG 在 MAPPO 基础上增加物理感知图表示和 Transformer 时序记忆。当前性能最好的主版本是冻结 GraphEncoder 和 TemporalMemory 的 V2.2.2；端到端联合训练 V3.1 虽然能更新表示模块，但综合性能与稳定性没有超过冻结版本。

## 2. 代码组成与数据流

### 2.1 关键代码

- `env/cpgrid_env.py`：Gym 风格多智能体电网环境，负责 reset、step、攻击、潮流和观测闭环。
- `env/powerflow_solver.py`：基于 Pandapower 的潮流计算。
- `env/attack_simulator.py`：FDI、DoS、Breaker 攻击与 Breaker 暂态恢复。
- `env/topology_manager.py`：线路断开、恢复和拓扑状态管理。
- `env/reward_calculator.py`：Reward 分解与终止惩罚。
- `graph/graph_encoder.py`：PhyG 的物理图编码器。
- `memory/transformer_memory.py`：历史图嵌入的 Transformer Memory。
- `policy/actor.py`：共享 GraphActor。
- `adapter/light_mappo.py`：PhyG 的 MAPPO/PPO 更新。
- `train.py`：PhyG 训练、在线评估、checkpoint 和日志入口。
- `run_baseline_suite.py`：独立 baseline 训练入口，不改动 PhyG 主代码。
- `evaluate_baseline_suite.py`：七种 baseline 的统一 100-seed 离线评估。
- `offline_checkpoint_evaluation.py`：PhyG checkpoint 重建和统一离线评估。
- `plot_baseline_comparison.py`：七种 baseline 各自的三 seed 2×2 训练曲线。
- `benchmark_model_cost.py`：参数量与策略推理延迟测试。

### 2.2 闭环流程

每个环境步按以下顺序运行：

1. AttackSimulator 推进已激活 Breaker 的持续时间并恢复到期线路；
2. 生成 FDI、DoS 或 Breaker 攻击；
3. Breaker 攻击改变实际线路状态，FDI/DoS 影响局部信息通道；
4. 将 14 个智能体动作映射为负荷 scaling 或发电机电压支撑；
5. Pandapower 根据线路状态和动作求解潮流；
6. 根据潮流结果构建局部观测、可信图数据和集中式 Critic 状态；
7. 计算 Reward、终止原因和物理指标；
8. 训练阶段将 transition 写入 rollout 并执行 MAPPO/PPO/QMIX 更新。

需要强调：当前 FDI/DoS 主要攻击局部观测或通信信息，PhyG 的图通道使用环境提供的可信物理图状态。Breaker 才会直接改变真实拓扑。因此实验支持的是“可信图状态辅助下的局部观测攻击防御”，不能表述为“所有全局测量和状态估计同时受攻击”。

## 3. 环境、观测和动作

### 3.1 环境

- 电网：IEEE 14-bus；
- 智能体：14 个母线智能体；
- 单回合最大步数：正式实验为 200；
- 潮流工具：Pandapower；
- 动作空间：`MultiDiscrete([3] × 14)`；
- 局部观测实际维度：21；
- 集中式 Critic 状态维度：72。

`config.py` 中旧的 `OBS_DIM=246` 是历史配置，不应在论文中当作当前局部观测维度；当前环境的 `observation_space["agent_0"]` 为 21 维。

### 3.2 Critic 全局状态

Critic 状态由以下信息拼接得到：

- 14 个节点的前 4 个物理特征，共 56 维；
- 14 个节点是否受断线影响的 mask；
- 活跃 Breaker 数量的归一化值；
- 当前回合时间进度。

合计为 72 维。该状态只在集中式训练/价值评估时使用，分布式执行 Actor 不直接读取完整全局状态。

### 3.3 动作物理含义

每个母线输出动作 0、1、2。动作含义取决于母线角色：

- 负荷母线：负荷 scaling 分别为 1.00、0.95、0.90；
- 发电机或平衡节点：电压支撑增量分别为 0、0.01、0.02 pu。

共享 Actor 可以减少参数量，但同一个离散动作在不同母线类型上对应不同物理控制。

## 4. 攻击模型

正式主实验配置：

- 每步攻击概率：0.35；
- FDI、DoS、Breaker 权重：0.45、0.45、0.10；
- Breaker 持续时间：10～20 步；
- 同时活跃 Breaker 上限：2；
- 单回合 Breaker 攻击次数上限：6；
- 排除可能造成孤岛的线路；
- 到期线路自动恢复。

三种攻击的作用路径不同：

- FDI：篡改目标智能体局部观测；
- DoS：阻断、冻结或延迟目标智能体局部信息；
- Breaker：断开真实线路，改变潮流和拓扑。

解释攻击消融时要注意：固定策略不读取观测，因此 FDI/DoS 不会改变固定策略动作；PhyG 又有可信图通道，因此局部 FDI/DoS 的物理影响可能被图信息旁路。不能由此推导 FDI/DoS 在现实系统中不重要。

## 5. Reward 与终止

单步 Reward 的真实实现为：

- 生存奖励：0.2；
- 负荷奖励：`0.8 × load_ratio`；
- 电压偏差惩罚：正常值偏离 1.0 pu 的均方项；
- 低电压惩罚：低于 0.95 pu 的幅度和比例；
- 高电压惩罚：高于 1.05 pu 的幅度和比例；
- 线路过载惩罚；
- 减载成本：`0.4 × (1-load_ratio)`；
- 发电机支撑成本；
- 终止惩罚：潮流不收敛和无效电压为 −10，电压崩溃为 −15。

可概括为：

\[
r_t=0.2+0.8L_t-P_V-P_{line}-0.4(1-L_t)-C_G+P_{terminal}.
\]

训练内部通常使用 `reward_scale=0.1` 改善优化数值，但日志和离线评估报告环境原始 Reward。

核心指标：

- 生存率：运行到 time limit 的 episode 比例；
- Reward：每回合原始 Reward 总和；
- 平均步数；
- 负荷保持率；
- 高/低电压率；
- 潮流不收敛率；
- Balanced Score：

\[
B=S+0.5L-0.5H,
\]

其中 \(S\) 为生存率，\(L\) 为负荷率，\(H\) 为高电压率。Balanced Score 用于模型选择和综合比较，不是训练 Reward。

## 6. PhyG 设计

### 6.1 GraphEncoder

GraphEncoder 输入：

- 节点特征 `[14,4]`；
- 边特征 `[L,3]`；
- `edge_index`；
- 节点有功注入。

它通过两层物理感知图消息传递和池化生成 64 维图嵌入，用于表达拓扑、邻接关系和电气状态。该设计与普通 GAT 的差异是显式使用电网边、注入和物理消息传递，而不是把所有节点当作无约束 token。

### 6.2 TemporalMemory

TemporalMemory 保存最近 10 个图嵌入，通过两层、4-head Transformer Encoder 生成 64 维历史表示。每个 episode 开始时清空 memory，防止不同场景泄漏。

### 6.3 Actor 与 Critic

Actor 对 14 个智能体共享参数。V2.2.2 Actor 输入为：

- 每个智能体自己的 21 维局部观测；
- 共享的 64 维图—时序表示。

Actor 输出每个智能体的 3 类动作 logits。Critic 使用 72 维集中式状态估计全局价值。

### 6.4 冻结与端到端

冻结 V2.2.2：

- GraphEncoder 和 TemporalMemory 参与前向推理；
- PPO 只更新 Actor 和 Critic；
- 总模型参数约 661.8K；
- 真正可训练参数约 49.2K。

端到端 V3.1：

- 表示模块逐步解冻并接受 PPO Actor 梯度；
- Actor/Critic 学习率 5e-5；
- 表示学习率 5e-6；
- Transformer dropout 为 0；
- Memory Gate 初值约 0.119；
- `value_clip=0.2`；
- Return 不标准化；
- Critic 更新 5 epochs。

联合训练日志记录图/记忆梯度、参数变化、Gate、Critic explained variance、KL 和 clip fraction。实验显示参数确实发生更新，但性能没有超过冻结版本。

## 7. Checkpoint 与评估协议

训练保存：

- `best_balanced.pt`：Balanced Score 最高；
- `best_reward.pt`：评估 Reward 最高；
- `best_survival.pt`：生存率优先，并结合负荷和高电压率排序；
- `final.pt`：训练结束模型；
- `latest.pt`：最近评估模型。

Baseline 每 50 个训练 episode 额外进行 20 个确定性评估 episode。训练期评估只用于 checkpoint 选择；论文主结果必须来自统一离线评估。

统一离线评估协议：

- 训练 seed：42、43、44；
- 测试 seed：60000～60099；
- 每个训练 seed 对同样 100 个测试场景进行确定性评估；
- 最大步数 200；
- 不更新参数、不写训练 Buffer；
- 主比较使用 `best_balanced.pt`。

PhyG 在正式 100-seed 评估前还进行了 20-seed checkpoint 重建检查，确保 GraphEncoder、Memory、Actor 和 Critic 恢复后的结果与训练期评估一致。

## 8. 独立 Baseline 设计

所有 baseline 复用同一个 `CPGridEnv`、Reward、攻击配置、动作语义、训练 seed 和测试 seed，不修改 PhyG 主代码。

### 8.1 PPO

单个集中式策略读取 72 维全局状态，并使用 14 个三分类动作头。联合策略按因子化形式生成动作，不构建 \(3^{14}\) 的巨大联合离散空间。

### 8.2 IPPO

共享局部 Actor 和共享局部 Critic，Actor/Critic 都只读取每个智能体自己的 21 维观测。价值、Return 和 Advantage 按 `[T,14]` 逐智能体计算。

### 8.3 MAPPO

共享局部 Actor 读取 21 维局部观测；集中式 Critic 读取 72 维全局状态。不使用 GNN 和 Transformer，是隔离 PhyG 图—时序表示贡献的重要基线。

### 8.4 GRU-MAPPO

共享 GRU Actor 对局部观测历史建模，Critic 仍集中式。该实现支持 episode 内 hidden state 连续传递。论文中应如实说明其当前实现属于 hidden-state rollout；如果未采用完整 truncated-BPTT sequence minibatch，不应宣称完全复现某一特定官方 recurrent MAPPO 实现。

### 8.5 GAT-MAPPO

使用真实 `node_feats`、`edge_feats`、`edge_index` 和 injection 接入标准图注意力编码，再由共享策略产生节点动作。它用于比较通用图聚合与 PhyG 物理感知图建模。

### 8.6 QMIX

每个智能体使用局部观测和 agent ID 输入共享 GRU Agent-Q 网络；Mixing Network 读取 72 维全局状态，将局部 Q 单调混合为全局 \(Q_{tot}\)。训练使用 episode replay、target network 和 epsilon 探索。QMIX 属于 off-policy 离散 MARL 基线，公平性按相同环境交互预算衡量，而非梯度更新次数。

### 8.7 MAT

将 14 个局部观测编码为 Transformer token，并按固定母线顺序自回归生成 14 个动作。联合 log probability 用于 PPO 更新，集中式 Value head估计价值。它代表通用 Transformer MARL；与 PhyG 不同，MAT 不显式编码电网线路物理结构。

## 9. 核心统一离线评估结果

七种 baseline 的三训练 seed 均值 ± 标准差：

| 方法 | 生存率 ↑ | Reward ↑ | 负荷率 ↑ | 高电压率 ↓ | Balanced Score ↑ |
|---|---:|---:|---:|---:|---:|
| PPO | 87.33% ± 1.15% | 107.45 ± 6.89 | 94.65% ± 2.75% | 62.62% ± 0.89% | 1.0335 ± 0.0067 |
| IPPO | 86.00% ± 3.46% | 104.40 ± 7.23 | 94.72% ± 2.20% | 64.68% ± 4.70% | 1.0102 ± 0.0157 |
| MAPPO | 84.00% ± 1.73% | 113.84 ± 1.52 | 97.48% ± 0.87% | 61.36% ± 1.27% | 1.0206 ± 0.0158 |
| GRU-MAPPO | 84.33% ± 0.58% | 112.44 ± 1.55 | 96.65% ± 0.20% | 62.13% ± 0.80% | 1.0159 ± 0.0039 |
| GAT-MAPPO | 83.67% ± 4.93% | 103.28 ± 10.77 | 96.44% ± 2.95% | 67.10% ± 6.35% | 0.9834 ± 0.0081 |
| QMIX | 85.33% ± 3.79% | 106.47 ± 6.88 | 95.93% ± 3.06% | 65.12% ± 3.35% | 1.0074 ± 0.0230 |
| MAT | 86.00% ± 2.00% | 91.54 ± 15.99 | 92.88% ± 3.03% | 71.75% ± 8.31% | 0.9657 ± 0.0375 |
| **PhyG V2.2.2** | **94.33% ± 2.52%** | **116.60 ± 3.90** | 97.41% ± 2.22% | 65.13% ± 1.78% | **约 1.1047** |

Balanced Score 的 PhyG 数值根据均值计算。正式论文若有逐训练 seed 的 Balanced Score，应优先报告三个 seed 分数的均值和标准差，而不是由汇总均值二次计算。

可以支持的结论：

- PhyG 生存率比最佳 baseline PPO 高约 7 个百分点；
- PhyG Reward 高于所有统一离线评估 baseline；
- PhyG 负荷率与 MAPPO 接近，明显高于 PPO、IPPO、QMIX 和 MAT；
- MAPPO 的高电压率优于 PhyG，说明 PhyG 并非每个单项指标都最好；
- PhyG 的主要优势是生存、Reward 和供电能力的综合平衡，而不是单项高电压率最低；
- MAT 参数多、推理慢且结果波动最大；
- 普通 GAT 没有稳定超过无图 MAPPO，说明“使用图网络”本身不自动带来电网控制优势。

## 10. 冻结与端到端结果

| 指标 | 冻结 PhyG V2.2.2 | 端到端 PhyG V3.1 |
|---|---:|---:|
| 生存率 | **94.33% ± 2.52%** | 86.67% ± 2.89% |
| Reward | **116.60 ± 3.90** | 115.18 ± 5.57 |
| 负荷率 | 97.41% ± 2.22% | 97.40% ± 1.11% |
| 高电压率 | **65.13% ± 1.78%** | 66.24% ± 3.19% |
| Balanced Score | **约 1.1047** | 1.0225 ± 0.0314 |
| 总参数量 | 约 661.8K | 约 661.8K |
| 可训练参数量 | **约 49.2K** | 约 661.8K |
| 后期退化 | 较小 | 较明显 |

合理解释：冻结表示提供稳定的结构先验，并显著减少优化器需要更新的参数；端到端 PPO 信号噪声大，图与时序模块的小幅漂移不一定改善控制策略。当前结论必须限定为“在当前环境、训练预算和超参数下”，不能推广为所有任务中冻结必然优于联合训练。

V3.2 测试 Return 标准化与 Critic 10 epochs，Critic 数值指标改善但策略性能下降；V3.3 关闭 Value Clipping 后性能从 V3.2 恢复，但仍不如 V3.1。消融表明当前任务应保留 `value_clip=0.2`、不标准化 Return、Critic 5 epochs。

## 11. 轻量化与推理成本

当前 CPU benchmark 的原始延迟结果：

| 方法 | 平均延迟 | P95 | 决策频率 |
|---|---:|---:|---:|
| QMIX | 0.153 ms | 0.180 ms | 6523/s |
| MAPPO | 0.203 ms | 0.224 ms | 4936/s |
| PPO | 0.206 ms | 0.245 ms | 4861/s |
| IPPO | 0.230 ms | 0.279 ms | 4341/s |
| GRU-MAPPO | 0.315 ms | 0.364 ms | 3176/s |
| GAT-MAPPO | 0.456 ms | 0.536 ms | 2193/s |
| PhyG V2.2.2 | 1.140 ms | 1.361 ms | 877/s |
| MAT | 3.797 ms | 4.504 ms | 263/s |

参数量必须使用唯一参数统计。旧 benchmark CSV 对部分 baseline 使用 `module.modules()` 后重复累加，不应直接用于论文。核验后的唯一参数量约为：

| 方法 | 唯一总参数量 |
|---|---:|
| IPPO | 39,172 |
| MAPPO | 45,700 |
| PPO | 57,259 |
| GAT-MAPPO | 93,444 |
| GRU-MAPPO | 128,260 |
| QMIX | 222,724 |
| PhyG | 661,766 |
| MAT | 1,305,348 |

PhyG 冻结版总参数约 661,766，但真正可训练参数仅约 49,156；其余约 612,610 个表示参数在训练中冻结。PhyG 不是推理最快或总参数最少的方法，其轻量化主张应表述为：

- 冻结训练显著减少可训练参数和反向传播开销；
- 1.14 ms 策略推理延迟仍满足当前仿真实时控制需求；
- 相比 MAT，PhyG 参数更少、延迟更低、性能显著更好；
- 相比简单 PPO/MAPPO，PhyG 用可接受的额外推理成本换取更高生存率和综合性能。

推荐散点图：横轴为平均推理延迟，纵轴为 Balanced Score；左上角代表低延迟和高性能。PhyG 应被解释为性能—成本折中，而非绝对最轻模型。

## 12. Checkpoint 退化

Baseline 和端到端模型普遍出现训练期峰值后下降：

- PPO seed 44 在 Episode 350 左右内部评估 Reward 达到 122.72，后期下降；
- MAPPO 三个 seed 的 best-balanced 都较早出现在 Episode 149，最终评估显著波动；
- GRU-MAPPO、GAT-MAPPO 和 V3.1 也存在不同程度后期退化；
- V2.2.2 的 `final.pt` 平均生存率约 77.33%，而 `best_balanced` 为 94.33%。

这一结果支持：

- 训练结束模型不等于最佳模型；
- 在线小样本评估用于模型选择是必要的；
- 最终性能必须由独立、统一测试 seed 验证；
- 论文应同时给出 best 和 final 的差值，避免只报告峰值而不解释选择规则。

建议退化表字段：方法、最佳 Episode、最佳 Reward、最终 Reward、Reward 下降、最佳生存率、最终生存率、Balanced Score 下降。

## 13. 结构与攻击消融

已有冻结模块诊断模式：

- `full`：局部观测 + GNN + Transformer；
- `no_gnn`：移除图输入；
- `no_transformer`：移除时序记忆；
- `local_only`/`mix`：按实验脚本的具体定义解释。

如果这些模式是在同一已训练模型上关闭输入通道，论文应称为“零样本诊断消融”或“模块作用诊断”，不能称为四种结构从头训练的正式消融。它能说明 Actor 是否实际依赖这些信息，但不能完全隔离训练阶段的结构贡献。

攻击消融应区分无攻击、FDI、DoS、Breaker、混合攻击和增强混合攻击，报告生存率、Reward、负荷率、高电压率、潮流失败率及相对于无攻击的性能下降。

## 14. 统计显著性分析

数据基础完整：七种 baseline × 三训练 seed × 相同 100 个测试 seed，PhyG 也保存了逐 episode 原始结果。配对键为 `training_seed + test_seed`。

检验方案：

- Reward、步数、负荷率、高电压率：配对 Wilcoxon 符号秩检验；
- 生存结果：精确 McNemar/配对二项检验；
- 对全部比较使用 Holm 校正；
- 同时报告实际差值，不能只报告 p 值。

PhyG 相对 baseline 的三训练 seed 平均差值：

| 对比 | Reward 差值 | 负荷率差值 | 高电压率差值 | 生存率差值 |
|---|---:|---:|---:|---:|
| MAPPO | +2.76 | −0.00068 | +0.0378 | +10.33 个百分点 |
| IPPO | +12.19 | +0.0269 | +0.0046 | +8.33 个百分点 |
| PPO | +9.15 | +0.0276 | +0.0252 | +7.00 个百分点 |
| GRU-MAPPO | +4.15 | +0.0076 | +0.0300 | +10.00 个百分点 |
| GAT-MAPPO | +13.32 | +0.0097 | −0.0196 | +10.67 个百分点 |
| QMIX | +10.12 | +0.0148 | +0.0002 | +9.00 个百分点 |
| MAT | +25.05 | +0.0453 | −0.0661 | +8.33 个百分点 |

解释原则：

- Reward 对 PPO 的优势在三个训练 seed 上均通过严格校正；
- Reward 对其他方法多为方向一致，但严格 Holm 校正后存在训练 seed 依赖；
- 生存率对所有 baseline 均方向一致地提高 7～10.67 个百分点，但二元指标在单训练 seed、100 样本和保守校正下未全部显著；
- PhyG 对多数方法提高负荷率，但比 MAPPO 略低约 0.07 个百分点，工程幅度极小；
- PhyG 的高电压率并非对所有方法更低，因此不能声称所有单项安全指标最佳。

统计结果文件：

- `baseline_comparison/evaluation/significance_by_training_seed.csv`；
- `baseline_comparison/evaluation/significance_summary.csv`。

论文应将统计显著性作为“差异是否可能由测试场景偶然波动造成”的证据，而不是把 p 值等同于工程重要性。生存率提高 7 个百分点即使在极保守校正下未全部显著，仍有明确工程意义，应同时报告差值、置信区间和不一致配对数量。

## 15. 建议的实验结果组织

### 15.1 核心方法对比

用一张表展示 PPO、IPPO、MAPPO、GRU-MAPPO、GAT-MAPPO、QMIX、MAT、PhyG 的生存率、Reward、负荷率、高电压率和 Balanced Score，全部为统一离线评估三训练 seed 的均值 ± 标准差。最佳值加粗，第二名可下划线。

### 15.2 训练过程

正文展示 PhyG V2.2.2 的三 seed 曲线，并选 PPO、MAPPO 作为代表性对比。每种方法内部应展示三 seed，或展示三 seed 均值加标准差阴影；不能只挑最好 seed。七种 baseline 的独立 2×2 图由 `plot_baseline_comparison.py` 生成，其他方法可放附录。

### 15.3 结构消融

用 full、no_gnn、no_transformer、local_only/mix 的四指标柱状图，并明确它是诊断消融还是重训消融。

### 15.4 冻结与端到端

用 V2.2.2 与 V3.1 的三 seed 曲线和汇总表，展示性能、seed 波动、后期退化、总参数量和可训练参数量。核心论点是冻结版本在当前任务中具有更好的性能—训练成本折中。

### 15.5 轻量化

用参数/延迟表和“推理延迟—Balanced Score”散点图。正文不要声称 PhyG 参数最少，而应强调其在约 1.14 ms 延迟下获得最高综合性能，且冻结训练只更新约 49.2K 参数。

### 15.6 Checkpoint 退化

选 PPO、MAPPO、GAT-MAPPO 和 V3.1 展示内部评估曲线与 best/final 表格，说明模型选择的重要性。

### 15.7 统计显著性

主文给出 PhyG 相对代表性强基线 PPO、MAPPO、QMIX、MAT 的差值、校正 p 值和是否显著；完整 7 方法 × 5 指标结果放附录。

## 16. 可支持的主要论点

1. 在当前 IEEE14 混合攻击环境下，PhyG 的统一离线生存率、Reward 和综合分数优于七种代表性 baseline。
2. 普通 MAPPO 能获得较高 Reward 和负荷率，但生存率较低；PhyG 的价值是更好的安全—供电综合平衡。
3. 普通 GAT 和通用 MAT 并未自动适应电网任务，物理结构先验比单纯增加注意力层更有效。
4. 冻结图—时序表示比端到端联合更新更稳定，并把可训练参数从约 661.8K 降到约 49.2K。
5. PhyG 不是推理速度最快的方法，但 1.14 ms 的完整策略前向开销仍较低，且明显快于 MAT。
6. Checkpoint 退化普遍存在，统一模型选择和离线测试是可信评估的必要环节。

## 17. 不能支持或必须谨慎的表述

不要写：

- PhyG 在所有单项指标上都最佳；MAPPO 等方法的高电压率更低。
- GNN 和 Transformer 已经端到端学习到最优表示；最佳 V2.2.2 是冻结表示。
- FDI/DoS 直接改变了真实电网拓扑；当前只有 Breaker 改变拓扑。
- PhyG 是参数最少、推理最快的方法；QMIX、PPO、MAPPO 更快更小。
- 统计上显著等于工程上重要，或未显著等于完全没有优势。
- MAT baseline 等同于所有 MAT 官方实现；应按本项目的接入结构准确描述。
- 当前结果可直接推广到真实大规模电网、SCADA 或国家电网生产系统。
- 端到端训练在所有任务中都不如冻结训练；该结论仅限当前任务和预算。

## 18. 尚需人工完成的论文工作

无需再进行长时间训练即可完成的工作：

- 从现有 CSV 生成最终主结果表；
- 修正 benchmark 参数重复计数后生成正式轻量化表；
- 生成性能—延迟散点图；
- 生成冻结与端到端汇总图；
- 整理 checkpoint 退化表；
- 从统计结果中选主文与附录表；
- 查阅并补充 PPO、IPPO、MAPPO、QMIX、MAT、GAT、电网 RL 和信息物理攻击文献；
- 补充硬件、软件版本和运行线程配置；
- 根据期刊格式完成摘要、引言、相关工作、方法推导和参考文献。

如无审稿要求，当前实验链已经覆盖方法对比、多 seed、统一 100-seed 测试、冻结/端到端、模块诊断、攻击鲁棒性、checkpoint 退化、轻量化和统计显著性，不建议继续无限增加长训练实验。
