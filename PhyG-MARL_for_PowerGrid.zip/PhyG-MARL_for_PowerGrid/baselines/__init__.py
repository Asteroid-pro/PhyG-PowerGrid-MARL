"""Independent, paper-grade baseline implementations for PhyG comparisons."""
