"""Shared baseline training, rollout, checkpoint, and metric utilities."""
