# 表示—策略解耦方向：实验方案草案（v0.1）

> 目标：把"冻结表示优于端到端联合训练"从**混杂观察**升级为**因果证据**，为论文的"表示—策略解耦"叙事补齐三个缺口。
> 本文档所有命令均已对照当前代码核实（train.py / adapter/light_mappo.py / offline_checkpoint_evaluation.py / evaluate_attack_ablation.py 的 CLI 与 checkpoint 键名）。

---

## 0. 一句话目标与核心研究问题

**目标**：证明在 IEEE14 混合攻击 MARL 任务中，把表示学习与策略学习**解耦**（冻结表示、只训 49.2K 参数的策略头）在**同等超参数**下优于端到端联合训练，并定位其机理来源（物理结构先验 vs 任意随机投影）。

**三个研究问题（RQ）**：

- **RQ1（缺口#1，因果性）**：控制全部超参数后，冻结（frozen）是否仍优于联合（joint）？联合解冻时机是否影响结论？
- **RQ2（缺口#2，解耦的"另一半"）**：给表示加一个 stage-1 学习阶段（预测预训练 / 早停联合），能否进一步超过随机冻结？
- **RQ3（缺口#3，机理归因）**：随机特征中的性能来源是"物理结构（图聚合 + KCL 残差）"还是"任意冻结随机投影"？

---

## 1. 术语与基准事实

| 记号 | 含义 | 当前证据 |
|---|---|---|
| **R0** | frozen + 随机初始化表示（= V2.2.2 的实质） | 生存率 94.33% ± 2.52%，全项目最优 |
| **R1** | joint，表示从 episode 0 起可训练 | 无（V3.x 超参不同，不可比） |
| **R2** | joint，表示在 episode 100/200 解冻（V3.1 计划） | 有但混杂，需重跑 |
| **P1** | stage-1 预测预训练表示 → 冻结训策略 | 无（需新脚本） |
| **P2** | 早停联合 → 取表示权重 → 冻结重启 | 无（需新 flag） |
| **S1** | 冻结 GNN，去掉 KCL 残差项（λ_KCL=0） | 无 |
| **S2** | 冻结随机 MLP（无图结构、无注意力、无 KCL） | 无 |

**关键事实（已核实代码）**：V2.2.2 的 GraphEncoder 与 TemporalMemory 是训练开始时随机初始化、全程 `requires_grad=False`，代码库中不存在任何预训练阶段。因此 **R0 = 随机特征 + 策略头**，这是全部实验的基准线。

---

## 2. 统一固定超参（消除混杂的核心措施）

V2.2.2 与 V3.1 的劣化可能来自超参差异而非"联合训练"本身。所有 7 个 cell 必须共用同一套 actor/critic 超参，**唯一变量 = 表示是否训练 / 如何初始化**。

| 超参 | FIXED_HP_A（主方案，贴近 V2.2.2 冠军配置） | FIXED_HP_B（稳健性复核，V3.1 风格） |
|---|---|---|
| actor_lr / critic_lr | 1e-4 / 1e-4 | 5e-5 / 5e-5 |
| entropy_coef | 0.003 | 0.005 |
| value_clip | 0.0 | 0.2 |
| critic_epochs | 10 | 5 |
| normalize_returns | True | False |
| 其余（gamma 0.99、lam 0.95、clip 0.15、ppo_epochs 5、target_kl 0.02、lr 线性衰减、reward_scale 0.1、1000 eps × 200 steps、攻击配置） | 全部一致 | 全部一致 |

> 说明：value_clip / critic_epochs / normalize_returns 目前在 `train.py` 的 `main()` 里被**硬编码**为 V3.1 值（0.2 / 5 / False），必须先暴露为 CLI 参数（见 §9 代码改动 #1）。
> 预算紧张时只跑 FIXED_HP_A，把 HP_B 降级为"仅对 R0 vs R1 复核"。

---

## 3. 实验矩阵总览

| Cell | 表示初始化 | 表示是否训练 | 超参 | Seeds | 回答 |
|---|---|---|---|---|---|
| R0 | 随机（物理 GNN + KCL） | 冻结 | A（+B 复核） | 42/43/44 | 基准线 |
| R1 | 随机 | episode 0 起联合训练 | A（+B 复核） | 42/43/44 | RQ1 |
| R2 | 随机 | episode 100/200 起联合训练 | A | 42/43/44 | RQ1（解冻时机） |
| P1 | 预测预训练 | 冻结 | A | 42/43/44 | RQ2 |
| P2 | 早停联合（300 eps） | 冻结重启 | A | 42/43/44 | RQ2 |
| S1 | 随机 GNN，λ_KCL=0 | 冻结 | A | 42/43/44 | RQ3 |
| S2 | 随机 MLP（无图） | 冻结 | A | 42/43/44 | RQ3 |

全部 cell 统一：1000 训练 episodes、200 steps、攻击概率 0.35（FDI/DoS/Breaker = 0.45/0.45/0.10）、离线评估 100 个测试 seed（60000–60099）、主比较 checkpoint = `best_balanced.pt`。

---

## 4. RQ1（缺口#1）：控制变量冻结 vs 联合

### 4.1 目的
消除"V2.2.2 赢在超参"的替代解释。同一套 FIXED_HP 下，只改变表示是否可训练。

### 4.2 命令（Windows PowerShell，当前机器；Linux 去掉注释行即可）

```powershell
# 每个 cell × seed 一条命令；示例为 R0/seed 42
python train.py --seed 42 --episodes 1000 --steps 200 --success_threshold 0.0 `
  --representation_mode frozen `
  --actor_lr 1e-4 --critic_lr 1e-4 --entropy_coef 0.003 `
  --value_clip 0.0 --critic_epochs 10 --normalize_returns `
  --output_dir decoupling_exp/r0_frozen/seed_42

# R1：表示从 episode 0 起训练（解冻阈值设为 0）
python train.py --seed 42 --episodes 1000 --steps 200 --success_threshold 0.0 `
  --representation_mode joint --representation_lr 5e-6 `
  --memory_unfreeze_episode 0 --graph_unfreeze_episode 0 `
  --actor_lr 1e-4 --critic_lr 1e-4 --entropy_coef 0.003 `
  --value_clip 0.0 --critic_epochs 10 --normalize_returns `
  --output_dir decoupling_exp/r1_joint_full/seed_42

# R2：V3.1 风格的延迟解冻
python train.py --seed 42 --episodes 1000 --steps 200 --success_threshold 0.0 `
  --representation_mode joint --representation_lr 5e-6 `
  --memory_unfreeze_episode 100 --graph_unfreeze_episode 200 `
  --actor_lr 1e-4 --critic_lr 1e-4 --entropy_coef 0.003 `
  --value_clip 0.0 --critic_epochs 10 --normalize_returns `
  --output_dir decoupling_exp/r2_joint_staged/seed_42
```

Linux 并行可用现有 `run_multiseed_parallel.py`（注意其内部未传 representation 参数，需给该脚本加透传参数，见 §9 改动 #2；或直接用 shell 循环 + `--no_affinity`）。

### 4.3 判读标准（假设 H1）

- **H1a**：`R0 > R1` 且差距 ≥ 现有 V2.2.2 vs V3.1 的水平（Balanced Score 差 ≥ 0.05、生存率差 ≥ 5pp）→ 解耦叙事成立，且**这次是干净证据**；
- **H1b**：`R0 ≈ R1`（±1pp 内）→ 说明之前差距主要来自超参；解耦方向大幅弱化，应转向"超参鲁棒性"叙事或放弃；
- **H1c**：`R1 > R2` → 延迟解冻无帮助，"逐步解冻"作为补救手段不成立（但仍可报告）；
- 附注：若 `R0 < R1`，直接推翻该方向，回到原"physics-MARL 系统"叙事。

---

## 5. RQ2（缺口#2）：学习表示的对照组

### 5.1 P1：stage-1 预测预训练 → 冻结

**设计**（新脚本 `pretrain_representation.py`，约 150–200 行）：

1. **数据收集**：随机策略（均匀采样三动作）在 `CPGridEnv` 中跑 200 episodes × 200 steps；每步记录
   - 输入：`node_feats [14,4]`、`edge_feats [L,3]`、`edge_index`、`node_injection [14]`（环境 `get_graph_data()` 已提供）；
   - 目标：**下一步**的物理量，推荐全局向量 `[load_ratio, mean|V−1|, max_line_loading, low_violation_frac, high_violation_frac]`（每步 `step()` 返回的 info 已含 load_ratio / min·max·mean voltage；逐节点 `vm_pu` 需从 `env.powerflow_solver` 读取，实现时确认接口，退而求其次用全局向量即可）。
2. **预训练**：随机初始化的 GraphEncoder + TemporalMemory（与 train.py 完全同构）+ 一个 3 层 MLP 预测头；损失 = 预测头输出与目标向量的 MSE（标准化后）；Adam 1e-4，训练到验证集收敛（预计几百 epoch，CPU 分钟级）。
3. **产出**：`decoupling_exp/pretrain/representation_pretrained.pt`，键名与 checkpoint 一致（`graph_encoder_state_dict` / `memory_state_dict`）。

**Stage-2 命令**（依赖 §9 改动 #3 的 `--load_representation_from`）：

```powershell
python train.py --seed 42 --episodes 1000 --steps 200 --success_threshold 0.0 `
  --representation_mode frozen --load_representation_from decoupling_exp/pretrain/representation_pretrained.pt `
  --actor_lr 1e-4 --critic_lr 1e-4 --entropy_coef 0.003 `
  --value_clip 0.0 --critic_epochs 10 --normalize_returns `
  --output_dir decoupling_exp/p1_pretrain_frozen/seed_42
```

### 5.2 P2：早停联合 → 取表示 → 冻结重启

1. 跑 R1（joint full）至 300 episodes（其余参数同 R1），输出目录 `decoupling_exp/p2_pretrain_joint_stage/seed_42`；
2. 用 `latest.pt` 中 `graph_encoder_state_dict` / `memory_state_dict` 作为 stage-1 表示；
3. 以 `--load_representation_from .../latest.pt --representation_mode frozen` **全新重启**（actor/critic 重新随机初始化）训满 1000 episodes。

### 5.3 判读标准（假设 H2）

- `P1 > R0`：学习过的表示比随机表示更有用 → 完整的"预训练→冻结→策略"两阶段方法论成立（论文 Framing A/B 均可选）；
- `P1 ≈ R0`：随机特征已足够，学习表示无增益 → **这本身是可发表的发现**（"该任务中物理结构先验 + 随机投影即可，无需表示学习"），但叙事必须切换；
- `P1 > R1`：解耦（冻结）本身有增益，支持"策略梯度信号不适合驱动表示学习"的机理论点；
- P2 作为 P1 的低成本替代：若 `P2 ≥ R0`，说明即使表示来自联合训练的早停快照，冻结后策略学习仍受益 → 支持"解耦训练阶段"的普适性。

---

## 6. RQ3（缺口#3）：物理结构 vs 任意随机投影

### 6.1 两个新 cell 的实现

**S1（去 KCL）**：`PhysicsGNNLayer` 已支持 `lambda_kcl` 参数（当前取 `config.PHYSICS_LAMBDA_KCL=0.1`）。给 `train.py` / `graph_encoder.py` 增加 `--lambda_kcl 0.0` 透传（§9 改动 #4），其余与 R0 完全一致。

**S2（随机 MLP，无图结构）**：在 `graph_encoder.py` 新增约 25 行的 `RandomMLPEncoder`，**保持与 GraphEncoder 相同的输入输出接口**（输出 `(node_emb, graph_emb[64])`），实现：`node_feats` 均值池化 → Linear(4,64) → ReLU → Linear(64,64)，完全忽略 `edge_feats / edge_index / node_injection`；TemporalMemory 保持同构（同为随机 Transformer）。由 `--encoder_type mlp` 选择（§9 改动 #5）。

### 6.2 命令

```powershell
# S1
python train.py --seed 42 --episodes 1000 --steps 200 --success_threshold 0.0 `
  --representation_mode frozen --lambda_kcl 0.0 `
  --actor_lr 1e-4 --critic_lr 1e-4 --entropy_coef 0.003 `
  --value_clip 0.0 --critic_epochs 10 --normalize_returns `
  --output_dir decoupling_exp/s1_nokcl/seed_42

# S2
python train.py --seed 42 --episodes 1000 --steps 200 --success_threshold 0.0 `
  --representation_mode frozen --encoder_type mlp `
  --actor_lr 1e-4 --critic_lr 1e-4 --entropy_coef 0.003 `
  --value_clip 0.0 --critic_epochs 10 --normalize_returns `
  --output_dir decoupling_exp/s2_random_mlp/seed_42
```

### 6.3 判读标准（假设 H3）

- **H3a（理想）**：`R0 > S1 > S2` → 性能阶梯证明：图聚合有贡献、KCL 残差有独立贡献 → "物理结构在架构里、不在权重里"成为论文核心卖点；
- **H3b**：`R0 ≈ S1` 但 `S1 > S2` → 图聚合有效、KCL 项无独立贡献 → 论文改为"拓扑结构随机特征"叙事，KCL 只能作为实现细节；
- **H3c（最坏）**：`R0 ≈ S2` → 任何随机投影都行，物理结构是装饰 → **必须放弃 PhyG 架构卖点**，论文转为纯方法论文（"解耦 + 随机特征"）并大幅修改第 6 节设计描述；
- 判读依据：三 seed 离线评估的 Balanced Score / 生存率 / Reward 差值 + 统计检验，而非单 seed。

---

## 7. 统一离线评估与统计（所有 cell 共用）

```powershell
# 每个 cell 执行一次（--seeds 42 43 44）
python offline_checkpoint_evaluation.py `
  --root decoupling_exp/r0_frozen --output_dir decoupling_exp/eval/r0_frozen `
  --seeds 42 43 44 --steps 200 --mode full100
```

- 输出 `offline_checkpoint_summary.csv` / `offline_episode_results.csv`，与 baseline 协议完全同口径；
- 统计：复用 `evaluate_baseline_suite.py` 的方法论（配对 Wilcoxon / McNemar + Holm），写一个约 80 行的 `analyze_decoupling.py` 做 cell 间配对比较（键 = `training_seed + test_seed`）；
- **显著性预案**：若生存率差值在 100 测试 seed 下 Holm 校正后不显著（当前 baseline 比较的已知问题），把 `offline_checkpoint_evaluation.py` L245 的测试 seed 范围扩为 60000–60299（新增 `--mode full300`，约 10 行改动），纯评估无训练成本。

---

## 8. 增强攻击鲁棒性与机理分析（零训练成本）

### 8.1 攻击鲁棒性
对最终胜出的 2–3 个 cell（预期 R0、P1、R1）运行已有脚本：

```powershell
python evaluate_attack_ablation.py `
  --checkpoint_root decoupling_exp/r0_frozen --output_dir decoupling_exp/attack/r0_frozen `
  --training_seeds 42 43 44 --test_seed_start 60000 --test_episodes 100 --steps 200
```

验证"解耦优势在强攻击/单攻击类型下是否保持"（已有的 `attack_ablation_enhanced` 目录说明增强版配置可直接复用其思路）。

### 8.2 训练动力学（支撑机理叙事）
每个 cell 已产出 `ppo_update_metrics.csv`（含 `graph_grad_norm`、`memory_grad_norm`、`graph_parameter_relative_delta`、`approx_kl`、`clip_fraction`、`explained_variance`）。分析：
- R1/R2 中表示梯度的噪声水平（norm 方差）与参数漂移量，对照 R0 的零漂移；
- R1 后期性能退化与表示参数漂移的时序相关性（现有 V3.1 的"后期退化"现象应能复现并归因）；
- 产出 1–2 张图：表示参数相对变化量 vs episode、冻结/联合的 KL 与 clip fraction 对比。

---

## 9. 代码改动清单（全部为小改动，合计约 150 行）

| # | 文件 | 改动 | 用途 |
|---|---|---|---|
| 1 | `train.py` | 把 `value_clip / critic_epochs / normalize_returns` 从硬编码改为 CLI 参数（照抄现有 argparse 风格，约 15 行） | 实现 FIXED_HP_A/B |
| 2 | `run_multiseed_parallel.py` | 增加 `--representation_mode --actor_lr --critic_lr --entropy_coef --value_clip --critic_epochs --normalize_returns --load_representation_from --encoder_type --lambda_kcl` 透传给子进程 | Linux 多 seed 并行 |
| 3 | `train.py` | 新增 `--load_representation_from <path>`：训练开始前加载 `graph_encoder_state_dict / memory_state_dict`（约 12 行） | P1/P2 的 stage-2 |
| 4 | `train.py` + `graph_encoder.py` | 新增 `--lambda_kcl`，透传给 `PhysicsGNNLayer`（约 8 行） | S1 |
| 5 | `graph_encoder.py` + `train.py` | 新增 `RandomMLPEncoder` 类（约 25 行）+ `--encoder_type {physics,mlp}`（约 8 行） | S2 |
| 6 | 新文件 `pretrain_representation.py` | stage-1 数据收集 + 预测预训练 + 保存表示权重（150–200 行） | P1 |
| 7 | 新文件 `analyze_decoupling.py` | cell 间配对统计（Wilcoxon/McNemar/Holm）+ 结果表（约 80 行） | §7 |
| 8 | `offline_checkpoint_evaluation.py` | 新增 `--mode full300`（L245 范围参数化，约 10 行） | 显著性预案 |

**改动红线**：不修改 `CPGridEnv`、Reward、攻击配置、动作语义、观测维度；不改 `adapter/light_mappo.py` 的更新数学——保证与 baseline 协议可比。

---

## 10. 预算与排期（Windows CPU 机）

| 阶段 | 内容 | 预估 |
|---|---|---|
| Phase 0 | 代码改动 #1–#5（#6–#8 可并行） | 0.5 天 |
| Phase 1 | 每个 cell × 1 seed 的 20-episode smoke 测试，确认日志/checkpoint 键 | 0.5 天 |
| Phase 2 | P1 预训练数据收集与训练 | 数小时（CPU） |
| Phase 3 | 21 次正式训练（7 cells × 3 seeds × 1000 eps） | 单进程 2–5 小时/次；多核并行 2–4 天 |
| Phase 4 | 全 cell 离线评估 + full300 预案 + 统计 | 0.5 天 |
| Phase 5 | 攻击消融 + 动力学分析 + 更新 paper.md | 0.5 天 |

**并行建议（Windows）**：每 seed 一个 `Start-Process` 实例，按核数分批（建议 ≤ 并发 = 物理核数 − 2）；或直接用 3 个终端各跑一个 seed。所有输出目录统一挂在 `decoupling_exp/` 下，评估阶段再汇总。

**成本控制**：若 Phase 3 预算不足，优先保 R0/R1/S2（这三个 cell 决定叙事走向），P2 可降级为 1 seed 探索性结果。

---

## 11. 预期结果 → 论文叙事映射表

| 结果组合 | 可支持的论文叙事 |
|---|---|
| R0>R1 且 S0>S1>S2 | **完整方法论**：物理结构随机特征 + 解耦策略学习（Framing C，最强） |
| R0>R1 且 P1≥R0 | **两阶段范式**：预测预训练表示 → 冻结 → 轻量策略（Framing A/B） |
| R0>R1 但 P1≈R0 | **"表示学习非必要"发现**：结构先验 + 随机投影 + 解耦训练（诚实负结果，需强调机理分析 §8.2） |
| R0>R1 但 S2≈R0 | **纯训练范式论文**：删掉 PhyG 架构卖点，改为"解耦 + 冻结随机特征"（需重写方法节） |
| R0≈R1 | **方向不成立**：退回原"physics-MARL 防御系统"叙事，解耦只作为训练技巧一节 |

无论哪种组合，都必须沿用 paper.md §17 的诚实口径：结论限定于"当前任务、PPO 训练、预算与超参下"，不推广到所有 RL。

---

## 12. 公平性自检清单（提交/写作前逐项确认）

- [ ] R0/R1/R2/P/S 全部共用 FIXED_HP，唯一变量 = 表示是否训练/如何初始化；
- [ ] 所有 cell 的 actor/critic 结构完全一致（S2 只换 encoder，actor 不动）；
- [ ] 所有 cell 用同一 checkpoint 选择规则（best_balanced）与同一 100/300 测试 seed；
- [ ] 联合训练臂的表示学习率（5e-6）单独说明，并在论文中披露"已试过更高/更低 lr 的 V3.2/V3.3 系列"作为调参证据；
- [ ] 报告三 seed 均值 ± 标准差，不挑最好 seed；
- [ ] 统计显著性按 Holm 校正报告，生存率二元指标同时报告差值、CI 与不一致配对数量；
- [ ] 训练时间成本差异如实披露（joint 需要表示反向传播，wall-clock 更贵——这本身是解耦的一个卖点，但要实测数据支撑）。

---

## 13. 与现有资产的关系

- 本方案的所有结果目录统一放 `decoupling_exp/`，**不动** `results/`、`baseline_comparison/`、`offline_evaluation_v2_2_2/` 中的既有数据；
- 完成后把新的主结果表与判读结论回写 `paper.md` §10（冻结与端到端）并新增"解耦消融"小节；
- baseline 对比数据（7 方法 × 3 seeds）可直接引用，无需重跑。
