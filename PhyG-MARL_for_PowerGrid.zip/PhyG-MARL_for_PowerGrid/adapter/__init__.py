from .light_mappo import LightMAPPO

__all__ = ["LightMAPPO"]
